#define IDD_MAIN         100
#define IDB_1            100
#define IDB_2            101
#define IDB_3            102
#define IDB_PAUSE_RESUME 103
#define IDI_MAIN         200

#define WS_POPUP       0x80000000L
#define WS_CHILD       0x40000000L
#define WS_VISIBLE     0x10000000L
#define WS_CAPTION     0x00C00000L
#define WS_SYSMENU     0x00080000L
#define WS_TABSTOP     0x00010000L
#define BS_PUSHBUTTON  0x00000000L
#define BS_FLAT        0x00008000L
#define DS_CENTER      0x0800L
